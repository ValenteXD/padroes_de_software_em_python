from PlayerCharacter import PlayerCharacter

class Healer(PlayerCharacter):
    def atk(self):
        print("curandeiro ataca de longe e cura o time")
        return
    def defend(self):
        print("curandeiro se protege com o cajado temendo o ataque que virá")