from PlayerCharacter import PlayerCharacter

class Paladin(PlayerCharacter):
    def atk(self):
        print("paladino desfere um golpe forte")
        return
    def defend(self):
        print("paladino está em guarda, e parece não se afrontar pelo dano que vem")