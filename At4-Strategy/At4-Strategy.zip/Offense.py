from Strategy import Strategy

class Offense(Strategy):
    def exec(self):
        print("Os soldados avançam em um ataque ")