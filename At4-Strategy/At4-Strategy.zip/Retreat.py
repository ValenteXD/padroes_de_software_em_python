from Strategy import Strategy

class Retreat(Strategy):
    def exec(self):
        print("Os soldados recuam")