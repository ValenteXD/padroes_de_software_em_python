from Strategy import Strategy

class Stealth(Strategy):
    def exec(self):
        print("Os soldados avançam sorrateiramente")