from Strategy import Strategy

class Standby(Strategy):
    def exec(self):
        print("os soldados estão aguardando ordens")