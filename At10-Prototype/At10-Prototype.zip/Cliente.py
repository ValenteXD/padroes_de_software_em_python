# Feito por João Pedro Covello Valente 2122172BCC

from Battlefield import Battlefield

if __name__=="__main__":
    bf = Battlefield()
    while True:
        bf.render()
        bf.logic()
